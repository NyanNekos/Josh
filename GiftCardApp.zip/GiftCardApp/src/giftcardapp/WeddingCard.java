/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package giftcardapp;

import java.util.Random;

/**
 *
 * @author Josh
 */
public class WeddingCard extends GiftCard {

    String salu;
    String vers;
    String close;

    public WeddingCard() {
        salu = "";
        vers = "";
        close = "";
    }

    public void intialise() {
        salutations = new String[]{"Mrs/Mr\n", "To\n", "Dear"};
        verses = new String[]{"\nBest wishes!\n", "\nWe're/I'm so happy for you!\n", "\nWishing you lots of \nLove and happiness\n", "\nWishing you a long \nAnd happy marriage\n", "\nChristmas is here \nWishing you the best \nToday and always!\n", "\nBest wishes for a \nFun-filled future together\n", "\nSo happy to celebrate \nThis day with you both!\n"};
        closing = new String[]{"\nLots of love,", "\nBest wishes!", "\nMay all that you are, always be in love", "\nFrom", "\nMay you have many joys", "\nMay your years fulfill the beauty\nof the feelings expressed today"};
    }

    public void salutations() {
        Random random = new Random();
        int index = random.nextInt(salutations.length);
        salu = salutations[index];
    }

    public void verse() {
        Random random = new Random();
        int index = random.nextInt(verses.length);
        vers = verses[index];
    }

    public void closing() {
        Random random = new Random();
        int index = random.nextInt(closing.length);
        close = closing[index];
    }

    public String getSalu() {
        return salu;
    }

    public String getVers() {
        return vers;
    }

    public String getClose() {
        return close;
    }

}
