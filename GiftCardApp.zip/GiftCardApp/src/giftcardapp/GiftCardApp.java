/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package giftcardapp;

import javax.swing.JOptionPane;

/**
 *
 * @author Josh
 */
public class GiftCardApp {

    public static void main(String[] args) {
        String sender;
        String recipient;
        String type;

        sender = JOptionPane.showInputDialog(null, "Please enter Your name");
        recipient = JOptionPane.showInputDialog(null, "Please enter the recipient name ");

        do {
            type = JOptionPane.showInputDialog(null, "Please type which kind of card you would like to send to the recipient \n\n➜ Christmas \n\n➜ Wedding \n\n➜ Birthday");
        } while (!type.equalsIgnoreCase("Christmas") && !type.equalsIgnoreCase("Wedding") && !type.equalsIgnoreCase("Birthday"));

        if (type.equalsIgnoreCase("Christmas")) {

            ChristmasCard myChristmas = new ChristmasCard();
            myChristmas.intialise();
            myChristmas.salutations();
            myChristmas.closing();
            myChristmas.verse();
            JOptionPane.showMessageDialog(null, myChristmas.getSalu() + recipient + "\n" + myChristmas.getVers() + myChristmas.getClose() + "\n" + sender);

        } else if (type.equalsIgnoreCase("wedding")) {
            WeddingCard myWedding = new WeddingCard();
            myWedding.intialise();
            myWedding.salutations();
            myWedding.closing();
            myWedding.verse();

            JOptionPane.showMessageDialog(null, myWedding.getSalu() + recipient + "\n" + myWedding.getVers() + myWedding.getClose() + "\n" + sender);

        } else {

            BirthdayCard myBirthday = new BirthdayCard();
            myBirthday.intialise();
            myBirthday.salutations();
            myBirthday.closing();
            myBirthday.verse();

            JOptionPane.showMessageDialog(null, myBirthday.getSalu() + recipient + "\n" + myBirthday.getVers() + myBirthday.getClose() + "\n" + sender);

        }

    }

}


/*

helpfull code from the teacher,  use it for later!!


salutations = new String[]{​​"Dear","To"}​​ by Frances Sheridan

​​
 */
