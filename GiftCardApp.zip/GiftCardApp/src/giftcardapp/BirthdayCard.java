/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package giftcardapp;

import java.util.Random;

/**
 *
 * @author Josh
 */
public class BirthdayCard extends GiftCard {

    String salu;
    String vers;
    String close;

    public BirthdayCard(String recipient, String sender) {
        super(recipient, sender);
    }

    public BirthdayCard() {
        salu = "";
        vers = "";
        close = "";
    }

    public void intialise() {
        salutations = new String[]{"Dear\n", "To\n"};
        verses = new String[]{"\nI hope you get to do \nsomething fun to celebrate!\n", "\nI hope your birthday is the happiests\n", "\nWarmest wishes and love on your \nbirthday and always!\n", "\nWishing you a happy birthday \nAnd a year that’s blessed\n", "\nWarmest wishes and love on \nYour birthday and always!\n", "\nHave a great Birthday\n", "\nSorry there’s no money in here!,\nBut Happy Birthday\n"};
        closing = new String[]{"\nBest wishes!", "\nFrom", "\nRespectfully", "\nKind regards"};

    }

    public void salutations() {
        Random random = new Random();
        int index = random.nextInt(salutations.length);
        salu = salutations[index];
    }

    public void verse() {
        Random random = new Random();
        int index = random.nextInt(verses.length);
        vers = verses[index];
    }

    public void closing() {
        Random random = new Random();
        int index = random.nextInt(closing.length);
        close = closing[index];
    }

    public String getSalu() {
        return salu;
    }

    public String getVers() {
        return vers;
    }

    public String getClose() {
        return close;
    }

}
