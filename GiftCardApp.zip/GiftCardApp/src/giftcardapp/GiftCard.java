/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package giftcardapp;

/**
 *
 * @author Josh
 */
public class GiftCard {

    String recipient;
    String sender;
    String type;
    String salutations[];
    String verses[];
    String closing[];

    public GiftCard(String recipient, String sender) {
        this.recipient = recipient;
        this.sender = sender;
    }

    public GiftCard() {

        recipient = "";
        sender = "";

    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getRecipient() {
        return recipient;
    }

    public void setRecipient(String recipient) {
        this.recipient = recipient;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }
}
