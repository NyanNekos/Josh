/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package giftcardapp;

import java.util.Random;
import javax.swing.JOptionPane;

/**
 *
 * @author Josh
 */
public class ChristmasCard extends GiftCard {

    String salu;
    String vers;
    String close;

    public ChristmasCard(String recipient, String sender) {
        super(recipient, sender);

    }

    public ChristmasCard() {
        salu = "";
        vers = "";
        close = "";
    }

    public void intialise() {
        salutations = new String[]{"Dear\n", "To\n"};
        verses = new String[]{"\nMerry Christmas\n", "\nWarm Hugs\n", "\nMerry Xmas\n", "\nHappy Holidays\n", "\nChristmas is here \nHave a merry one!\n", "\nHave a great christmas\n", "\nWishing you a \nMerry Christmas!\n"};
        closing = new String[]{"\nHave your best \nChristmas ever!", "\nFrom", "\nPeace and joy to you \nand yours this Christmas season", "\nGrace and peace"};
    }

    public void salutations() {
        Random random = new Random();
        int index = random.nextInt(salutations.length);
        salu = salutations[index];
    }

    public void verse() {
        Random random = new Random();
        int index = random.nextInt(verses.length);
        vers = verses[index];
    }

    public void closing() {
        Random random = new Random();
        int index = random.nextInt(closing.length);
        close = closing[index];
    }

    public String getSalu() {
        return salu;
    }

    public String getVers() {
        return vers;
    }

    public String getClose() {
        return close;
    }

    public String[] getSalutations() {
        return salutations;
    }

    public String[] getVerses() {
        return verses;
    }

    public String[] getClosing() {
        return closing;
    }

}
